﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Bookstoria.AplicationLogic.Model
{
    public class Category
    {
        public Guid ID { get; set; }
        public string Type { get; set; }
    }
}
