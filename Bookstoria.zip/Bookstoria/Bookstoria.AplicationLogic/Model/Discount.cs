﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Bookstoria.AplicationLogic.Model
{
    public class Discount
    {
        public Guid ID { get; set; }
        public double Value { get; set; }
    }
}
